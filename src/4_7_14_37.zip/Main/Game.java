package Main;

import java.util.*;
import Main.Lutemon.*;
import Main.Storage.*;

public class Game {
    Storage storage = new Storage();
    Home home = new Home();
    TrainingArea ta = new TrainingArea();
    BattleField bf = new BattleField();
    private static final Scanner sc = new Scanner(System.in);

    public void addLutemon() {
        int i = 0;
        String name;
        System.out.println("Add 1) White, 2) Green, 3) Pink, 4) Orange, 5) Black");
        String s = sc.nextLine();
        try {
            i = Integer.parseInt(s);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        System.out.println("Give it a name:");
        name = sc.nextLine();

        switch (i) {
            case 1:
                storage.luteST.add(new White(name));
                break;
            case 2:
                storage.luteST.add(new Green(name));
                break;
            case 3:
                storage.luteST.add(new Pink(name));
                break;
            case 4:
                storage.luteST.add(new Orange(name));
                break;
            case 5:
                storage.luteST.add(new Black(name));
                break;
            default:
                System.out.println("Invalid option");
        }
        home.createLutemon(storage.luteST.get(storage.luteST.size() - 1));
    }

    public void listLutemons() {
        // System.out.println("There are the following Lutemons at Home:");
        // for(Lutemon lute: l) {
        //     System.out.println(lute.id + ": " + lute.color
        //             + '(' + lute.name + ')' + "att: " + lute.attack
        //             + "; def: " + lute.defense + "; exp:" + lute.experience
        //             + "; health: " + lute.health + '/' + lute.maxHealth);
        // }
        home.listHome();
        ta.listTrainningArea();
        bf.listBattleField();
    }
}
