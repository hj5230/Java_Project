package Main.Lutemon;

public abstract class Lutemon {
    public String name;
    public String color;
    public int attack;
    public int defense;
    public int experience;
    public int health;
    public int maxHealth;
    public int id;
    protected static int idCounter = 0;
    // ?Subclasses cannot access idCoumter if it's private?

    public void defense(Lutemon lutemon) {
        // statement
    }
    public void attack(int i){
        // statement
    }
    public int getNumberOfCreatedLutemons(){
        // statement
        return 0;
    }
}
