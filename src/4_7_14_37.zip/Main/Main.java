package Main;

import java.util.Scanner;
// import Main.Storage.*;
// import Main.Lutemon.*;

public class Main {
    private static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {

        boolean exit = false;
        Game game = new Game();

        while(!exit) {
            System.out.println("Welcome to the Lutemon simulator!\n"
            + "1) Create a Lutemon, 2) List all the Lutemons, 3) Move Lutemons, 4) Train\n"
            + "Lutemons, 5) Let them fight, 0) Exit");
            String s = sc.nextLine();
            int i = 0;
            try {
                i = Integer.parseInt(s);
            } catch(NumberFormatException e) {
                e.printStackTrace();
            }

            switch(i) {
                case 1:
                    game.addLutemon();
                    break;
                case 2:
                    game.listLutemons();
                    break;
                case 3:
                    // statement
                    break;
                case 4:
                    // statement
                    break;
                case 5:
                    // statement
                    break;
                default:
                    exit = true;
                    break;
            }
        }
        sc.close();
    }
}
