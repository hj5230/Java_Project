package Main.Storage;

import java.util.*;
import Main.Lutemon.*;

public class BattleField extends Storage {
    ArrayList<Lutemon> luteBF = new ArrayList<>();

    public void fight() {
        // statement
    }
    public void gotoBattleField() {
        // statement
    }
    public void listBattleField() {
        System.out.println("There are the following Lutemons at Battle field:");
        for(Lutemon lute: luteBF) {
            System.out.println(lute.id + ": " + lute.color
            + '(' + lute.name + ')' + "att: " + lute.attack
            + "; def: " + lute.defense + "; exp:" + lute.experience
            + "; health: " + lute.health + '/' + lute.maxHealth);
        }
    }
}
