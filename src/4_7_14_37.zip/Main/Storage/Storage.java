package Main.Storage;

import java.util.*;
import Main.Lutemon.*;
// import Main.Storage.*;

public class Storage {
    public ArrayList<Lutemon> luteST = new ArrayList<>();
}