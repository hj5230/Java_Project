package Main.Storage;

import java.util.*;
import Main.Lutemon.*;

public class TrainingArea extends Storage{
    ArrayList<Lutemon> luteTA = new ArrayList<>();
    
    public void train() {
        // statement
    }
    public void gotoTrainningArea() {
        // statement
    }
    public void listTrainningArea() {
        System.out.println("There are the following Lutemons at Training area:");
        for(Lutemon lute: luteTA) {
            System.out.println(lute.id + ": " + lute.color
            + '(' + lute.name + ')' + "att: " + lute.attack
            + "; def: " + lute.defense + "; exp:" + lute.experience
            + "; health: " + lute.health + '/' + lute.maxHealth);
        }
    }
}
