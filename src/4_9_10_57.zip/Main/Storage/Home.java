package Main.Storage;

import java.util.ArrayList;
import Main.Lutemon.*;

public class Home extends Storage {
    public ArrayList<Lutemon> luteHome = new ArrayList<>();

    public void createLutemon(Lutemon lutemon) {
        luteHome.add(lutemon);
    }

    public void goHome(Lutemon lutemon) {
        luteHome.add(lutemon);
        lutemon.health = lutemon.maxHealth;
    }
    public void listHome() {
        System.out.println("There are the following Lutemons at Home:");
        for(Lutemon lute: luteHome) {
            System.out.println(lute.id + ": " + lute.color
            + '(' + lute.name + ") att: " + lute.attack
            + "; def: " + lute.defense + "; exp:" + lute.experience
            + "; health: " + lute.health + '/' + lute.maxHealth);
        }
    }
    public Lutemon getLutemonHome(int id) {
        for(Lutemon lute: luteHome){
            if(lute.id == id) {
                return lute;
            }
        }
        return null;
    }
}
